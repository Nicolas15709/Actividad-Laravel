<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UsuariosController extends Controller
{
    public function editar($id)
    {
        $usuario = User::find($id);
        return view('usuarios.editar', compact('usuario'));
    }

    public function actualizar(Request $request, $id)
    {
        $usuario = User::find($id);
        $usuario->name = $request->name;
        $usuario->surname = $request->surname;
        $usuario->country = $request->country;
        $usuario->city = $request->city;
        $usuario->email = $request->email;
        $usuario->login = $request->login;
        $usuario->save();

        return redirect()->route('tabla-usuarios')->with('success', 'Usuario actualizado correctamente.');
    }

    public function eliminar($id)
{
    $usuario = User::find($id);
    $usuario->delete();
    return redirect()->route('tabla-usuarios')->with('success', 'Usuario eliminado correctamente.');
}

}

