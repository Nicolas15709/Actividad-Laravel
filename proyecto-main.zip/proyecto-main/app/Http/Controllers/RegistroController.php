<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class RegistroController extends Controller
{
    public function registrarUsuario(Request $request)
    {
        // Validar los datos del formulario
        $request->validate([
            'name' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'login' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        // Crear un nuevo usuario
        $usuario = new User();
        $usuario->name = $request->name;
        $usuario->surname = $request->surname;
        $usuario->country = $request->country;
        $usuario->city = $request->city;
        $usuario->email = $request->email;
        $usuario->login = $request->login;
        $usuario->password = bcrypt($request->password);
        $usuario->save();

        // Redireccionar al usuario después de registrar
        return redirect()->route('inicio-sesion')->with('success', '¡Cuenta creada exitosamente! Ahora puedes iniciar sesión.');
    }
}
