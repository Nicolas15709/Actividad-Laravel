<form action="{{ route('usuarios.actualizar', $usuario->id) }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
        <label for="name">Nombre:</label>
        <input type="text" id="name" name="name" class="form-control" value="{{ $usuario->name }}" required>
    </div>
    <div class="form-group">
        <label for="surname">Apellido:</label>
        <input type="text" id="surname" name="surname" class="form-control" value="{{ $usuario->surname }}" required>
    </div>
    <div class="form-group">
        <label for="country">País:</label>
        <input type="text" id="country" name="country" class="form-control" value="{{ $usuario->country }}" required>
    </div>
    <div class="form-group">
        <label for="city">Ciudad:</label>
        <input type="text" id="city" name="city" class="form-control" value="{{ $usuario->city }}" required>
    </div>
    <div class="form-group">
        <label for="email">Dirección de Email:</label>
        <input type="email" id="email" name="email" class="form-control" value="{{ $usuario->email }}" required>
    </div>
    <div class="form-group">
        <label for="login">Nombre de Usuario:</label>
        <input type="text" id="login" name="login" class="form-control" value="{{ $usuario->login }}" required>
    </div>
    <button type="submit" class="btn btn-primary btn-block mt-4">Guardar Cambios</button>
</form>
